__version__ = '0.0.3'

from baseer.core import Baseer as BaseerClass

class Baseer(BaseerClass):
    pass