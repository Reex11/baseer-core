__version__ = '0.0.2'

from baseer.core import Baseer as BaseerClass

class Baseer(BaseerClass):
    pass