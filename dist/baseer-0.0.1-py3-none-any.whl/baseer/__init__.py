__version__ = '0.0.1'

from baseer.core import Baseer as BaseerClass

class Baseer(BaseerClass):
    pass